fun main() {

    var premiados : IntArray = IntArray(100)
    var numero = 0
    var i : Int = 0

    while(i <= (premiados.size)-1) {

        numero = (((Math.random() * 1000) + 1).toInt())

        if (numero !in premiados){

            premiados[i] = numero
            i++

        }


    }

    for (x in 0..(premiados.size)-1) {

        println(premiados[x])

    }

}


