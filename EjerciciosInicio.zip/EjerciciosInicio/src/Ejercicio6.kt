import java.util.*

fun main() {

    val sc: Scanner = Scanner(System.`in`)
    var valor = 0

    do {

        print("Introduzca un valor entre 0 y 10: ")
        valor = sc.nextInt()

        if (!rangoNumero(valor)) {

            println("ERROR: valor incorrecto.")

        }

    } while (!rangoNumero(valor))

}

fun rangoNumero (valor : Int) : Boolean {

    if (valor in 0..10) return true

    return false

}
