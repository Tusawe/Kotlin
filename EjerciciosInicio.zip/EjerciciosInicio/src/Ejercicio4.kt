fun main() {

    var frase : String = "Hola buenos dias mi nombre es Jose Luis"
    var palabras  = frase.split(" ")
    
    for (i in 0..(palabras.size)-1) {
        
        println(palabras[i])
        
    }


}