import java.util.*

fun main() {

    val sc : Scanner = Scanner(System.`in`)
    var valor = 0

    do {

        print("Introduzca un valor entre 0 y 10: ")
        valor = sc.nextInt()

        if (valor !in 0..10) {

            println("ERROR: valor incorrecto.")

        }

    } while(valor !in 0..10)






}