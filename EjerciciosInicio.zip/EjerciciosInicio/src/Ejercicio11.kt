import java.io.File

fun main() {

    // Ruta absolta.
    val lineas = File("src/datos_Ejercicio11.txt").useLines { it.toList() }
    var array: IntArray = IntArray(lineas.size) {lineas[it].toInt()}

    var valor: Int = 0
    var flag: Boolean = false
    var contador = 0

    while (!flag) {

        flag = true

        for (i in 0 until ((array.size) - 1) - contador) {

            if (array[i] > array[i + 1]) {

                valor = array[i]
                array[i] = array[i + 1]
                array[i + 1] = valor

                flag = false

            }

        }

        contador++

    }

    for (i in 0 until array.size) {

        println(array[i])

    }

}