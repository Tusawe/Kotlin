import java.util.*

fun main() {

    val sc : Scanner = Scanner(System.`in`)

    print("Introduce una cantidad en euros: ")

    var valor : Double = sc.nextDouble()
    valor *= 0.00012

    println("El valor en Bitcoins es $valor")

}