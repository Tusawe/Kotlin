import java.io.File

fun main() {

    val url = "src/datos_Ejercicio12y13.txt"
    var texto : String = ""

    texto = leerFichero(url)

    var posicion : Int = buscarPalabra(texto, "ejercicios")

    println("La primera posicion de la palabra es $posicion")

}

fun buscarPalabra(texto : String, palabra : String) : Int {

    var posicion : Int = -1
    var palabras = texto.split(" ")

    for (i in palabras.indices) {

        if (palabras[i] == palabra) return i

    }

    return posicion

}