import java.io.File

fun main() {

    val url = "src/datos_Ejercicio12y13.txt"
    var texto : String = ""
    
    texto = leerFichero(url).replace(" ","")

    println("El numero total de caracteres es ${contarCaracteres(texto,'e')}")

}

fun contarCaracteres(texto : String, char: Char) : Int {

    var contador : Int = 0

    for (i in texto.indices) {

        if (texto[i] == char) contador++

    }

    return contador

}

fun leerFichero(url : String) : String {

    val lineas = File(url).readLines()
    var texto : String = ""

    for (i in lineas.indices){

        texto += lineas[i]

    }

    return texto

}