fun main () {

    var i = 0
    var primos = 0

    while (primos <= 100) {

        if (comprobarNumeroPrimo(i)) {
            primos++
            println(i)
        }

        i++
    }

}

fun comprobarNumeroPrimo(numero: Int): Boolean {

    if (numero == 1) return false

    if (numero == 2 || numero == 3) return true else {

        if (numero % 2 == 0) return false else {

            for (i in 3 until ((numero - 1) / 2) - 1 step 2) {

                if (numero % i == 0) return false

            }

        }

    }

    return true

}