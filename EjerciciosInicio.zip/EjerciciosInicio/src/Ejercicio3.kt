import java.util.*

fun main() {

    val sc : Scanner = Scanner(System.`in`)

    print("Introduce un valor para calcular su factorial: ")

    var valor = sc.nextInt()
    var factorial = 1

    if (valor >= 1) {

        for (i in 1..valor) {

            factorial *= i

        }

        println("El factorial de $valor es $factorial")

    } else {

        println("Debe ser mayor o igual a 1 para calcular su factorial.")

    }

}