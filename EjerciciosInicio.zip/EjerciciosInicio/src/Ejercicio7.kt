import java.util.*

fun main() {

    val sc : Scanner = Scanner(System.`in`)

    println("Escribe una frase: ")

    var frase : String = sc.nextLine()

    println("¿Qué desea hacer con la frase?")
    println("(1) Mayúsculas")
    println("(2) Minúsculas")
    println("(3) Capitalizarla")
    print("Seleccione una opción: ")

    var op : Int = sc.nextInt()

    when (op) {

        1 -> println(frase.toUpperCase())
        2 -> println(frase.toLowerCase())
        3 -> println(frase.capitalize())

    }


}