import java.util.*

fun main() {

    val sc : Scanner = Scanner(System.`in`)

    var array: IntArray = IntArray(10)

    println("Introduzca 10 numeros")

    for (i in 0 until array.size) {

        print("(${i+1}): ")
        array[i] = sc.nextInt()

    }

    var valor: Int = 0
    var flag: Boolean = false
    var contador = 0

    while (!flag) {

        flag = true

        for (i in 0 until ((array.size) - 1) - contador) {

            if (array[i] > array[i + 1]) {

                valor = array[i]
                array[i] = array[i + 1]
                array[i + 1] = valor

                flag = false

            }

        }

        contador++

    }

    for (i in 0 until array.size) {

        println(array[i])

    }

}