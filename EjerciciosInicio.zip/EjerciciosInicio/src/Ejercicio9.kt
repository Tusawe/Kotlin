fun main() {

    var numeros: IntArray = IntArray(2000)

    for (i in 0..(numeros.size)-1) {

        numeros[i] = (((Math.random() * 100) + 1).toInt())

    }

    for (i in 0..(numeros.size)-1) {

        println(numeros[i])

    }

    println("El numero maximo es ${calcularMaximo(numeros)}")
    println("El numero minimo es ${calcularMinimo(numeros)}")
    println("El numero medio es ${calcularMedia(numeros)}")

}

fun calcularMinimo(numeros : IntArray) : Int {

    var minimo : Int = numeros[0]

    for (i in 1..(numeros.size)-1) {

        if (minimo > numeros[i]){

            minimo = numeros[i]

        }

    }

    return minimo

}

fun calcularMaximo(numeros : IntArray) : Int {

    var maximo : Int = numeros[0]

    for (i in 1..(numeros.size)-1) {

        if (maximo < numeros[i]){

            maximo = numeros[i]

        }

    }

    return maximo

}

fun calcularMedia(numeros : IntArray) : Double {

    var media : Double = 0.0

    for (i in 0..(numeros.size)-1) {

       media += numeros[i]

    }

    media /= numeros.size

    return media

}